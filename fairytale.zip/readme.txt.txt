Fairy Tale by Cybernetic genetics
Sundown 2014

Modelling/Textures: Grass
Code/Character animation: Travis

This is our first Unity3D demo.

Used FreeSound samples:
http://www.freesound.org/people/klankbeeld/
http://freesound.org/people/jamesrodavidson/sounds/192365
http://freesound.org/people/ecfike/sounds/132874/
http://freesound.org/people/alex_audio/sounds/188608/
http://freesound.org/people/NoiseCollector/sounds/4513/
http://freesound.org/people/Robinhood76/sounds/55690/
http://freesound.org/people/sonidotv/sounds/238316/